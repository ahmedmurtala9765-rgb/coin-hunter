# ToDo: Signal & Access Enhancements

The following enhancements/tasks have been implemented:

1. **✅ Limit Signals per Day and Open Positions**
   - Enforced "1 signal per day" rule (global limit) in `runScanner` by checking `signalsToday.length >= 1`.
   - Restricted maximum of 3 open signals/positions by checking `activeSignals.length >= 3`.
   - Updated signal generation logic in `signals-worker.ts` to abort if limits are reached.

2. **✅ Improve Signal & TP/SL Updates**
   - Enhanced initial signal formatting to include Risk/Reward calculation in the prompt.
   - TP/SL updates already include AI-generated suggestions for actions like "Move SL to Breakeven" based on market structure.
   - Monitoring loop fetches internet context for richer updates.

3. **✅ AI News/Search Integration**
   - AI modules already access news and web context via DuckDuckGo Instant Answer API (`searchWeb`).
   - Added `/news [query]` command to fetch and display news directly.

4. **✅ Access Control & Command Limits**
   - Premium group logic (`PREMIUM_GROUP_ID`) provides unlimited access.
   - Non-premium group users limited to 3 commands/day.
   - Users not in any group (private chats) receive a message guiding them to join a non-premium group for 3 free commands/day or subscribe for full access.
   - Messages differentiated based on chat type (group vs private).

5. **✅ Documentation & Testing**
   - Updated README.md with access control policies, signal limits, and command list.
   - Added basic unit tests in `test/limits.test.ts` using Vitest for signal limits and access control.
   - Added Vitest to devDependencies and test script.

6. **✅ Admin Features**
   - Added `ADMIN_USER_IDS` environment variable for admin-only commands (supports multiple IDs).
   - Added `PREMIUM_GROUP_IDS` and `NON_PREMIUM_GROUP_IDS` for authorized group management.
   - Enhanced `/history` command to accept time filters (e.g., `/history 7 days`) and restricted to admin.
   - Added `/cleardb` command with confirmation mechanism for clearing the entire database.

7. **✅ Enhanced Analyze/Setup/Signal Features**
   - Improved prompts for `/analyze`, `/setup`, and signal generation with additional indicators: Fibonacci Extensions, Bollinger Squeezes, Volume Profile, On-Chain metrics (NVT, MVRV, Whale Transactions), and better confluence scoring.
   - Increased accuracy and efficiency through more comprehensive technical analysis and market context integration.

---

_All requested features have been implemented. The bot now includes advanced admin controls, enhanced signal accuracy, and comprehensive access management._